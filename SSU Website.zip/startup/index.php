<?php 
	$page_name="StartupStratford";
	include_once("includes/header.php");
?>
	<span class="float_button_bottom"> <a href="about.php#howto">HOW TO APPLY</a></span>

	<div class="main_imageslide_big">
		<img src="content/index.jpg"/>
	</div>
<?php 
	include_once("includes/footer.php");
?>