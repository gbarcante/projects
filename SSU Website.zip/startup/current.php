<?php
	$page_name="Our Start Ups";
	include_once("includes/header.php");
?>
<div>
	<div class="current_startups">
		<div class="startup some-idea2">
			<div class="result_summ">
				<h2>&nbsp;&nbsp; AVON INTERACTIVE</h2>
				<p>Collect points and never miss a play again...</p>
			</div>
			<div class="result_link">
				<p class="result_link"><a class="result_link">VIEW MORE</a></p>
			</div>
		</div>
		<div class="startup some-idea1">
			<div class="result_summ">
				<h2>&nbsp;&nbsp; PLANT IT</h2>
				<p>The revolution of seed planting starts now! Plant IT provides high efficiency...</p>
			</div>
			<div class="result_link">
				<p class="result_link"><a class="result_link">VIEW MORE</a></p>
			</div>
		</div>
	</div>
</div>

<?php 
	include_once("includes/footer.php");
?>